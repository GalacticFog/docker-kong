#Gestalt Security Kong plugin

This is a custom plugin for Kong 0.10.3.  This is a plugin written in lua and implements their plugin interface.
