#Gestalt Security Kong plugin

This is a custom plugin for Kong 0.10.3.  This is a plugin written in lua and implements their plugin interface.

#Installation

To build this plugin you simply tar the contents like so :

`tar cvf gestalt-security-kong.tar INSTALL.txt README.md kong/`

Then you have to copy the tar to the directory where we build the docker-kong container :

`cp gestalt-security-kong.tar ../docker-kong`

Now we need to build the docker kong image and use it to test the new plugin.

The plugin can be enabled in Kong by issuing a post like so :

`
http http://<kong_host>:8001/plugins <
{
    "name" : "gestalt-security-kong",
    "config.auth_url": "http://<sec_host>:<sec_port>/accounts/self",
    "config.auth_token_url": "http://<sec_host>:<sec_port>/root/oauth/issue",
    "config.auth_realm": "http://<sec_host>:<sec_port>/oauth/issue",
    "config.app_key": "<api_key_for_gestalt_security>",
    "config.app_secret": "<api_secret_for_gestalt_security>"
}
`
