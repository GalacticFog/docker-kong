local BasePlugin = require "kong.plugins.base_plugin"

local CustomHandler = BasePlugin:extend()
local LOG_LEVEL = ngx.NOTICE

function CustomHandler:new()
  CustomHandler.super.new(self, "my-custom-plugin")
end

function log( thing )
  ngx.log( LOG_LEVEL, thing )
end

function CustomHandler:access(config)
  CustomHandler.super.access(self)
  log( 'starting auth plugin...')

  -- variables read form the environment
  local auth_url 	= config.auth_url
  local token_url 	= config.auth_token_url
  local auth_realm 	= config.auth_realm
  local app_key 	= config.app_key
  local app_secret 	= config.app_secret
  local auth_header = ngx.req.get_headers().authorization

  -- COOKIES!

  local cookie = nil
  if ngx.var.cookie ~= nil then
    cookie = ngx.var.cookie_auth-token
  end

  local bearer_token = ""

  -- Check that the cookie exists.
  if not auth_header or auth_header == '' then
    if cookie ~= nil then
      log( 'FOUND Cookie : ' + cookie )
      bearer_token = cookie
    end
  end

  -- check that the header is present, and if not send authenticate header
  if not auth_header or auth_header == '' then
    log( 'FAILED to find Authorization header' )
    ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
    ngx.exit(ngx.HTTP_UNAUTHORIZED)
  end

  local http = require "resty.http"
  local hc = http:new()

  -- if they handed us a Bearer token, simply use it
  if string.find( auth_header, "Bearer" ) then
    log( 'FOUND bearer token : ' .. auth_header )

    local divider = auth_header:find(' ')
    local token = auth_header:sub(divider+1)

    bearer_token = token
  end

  --if we've either found a token or used a cookie, just test it
  if bearer_token ~= nil and bearer_token ~= '' then


    log( 'sending request to ' .. auth_url )

    local h = "Bearer " .. bearer_token

    --local ok, code, headers, status, body  = hc:request {
    local res, err = hc:request_uri( auth_url, {
      timeout = 3000,
      method = "GET",
      headers = { ["Authorization"] = h
      }
    })

    if( res ~= nil ) then
      -- log( 'response code: ' .. res.status )
      if res.status == ngx.HTTP_OK then
        log( 'successfully authed with bearer credentials ' .. auth_header )
        return
      end
    end

    -- log( 'error message : ' .. err )
  end

  if auth_header ~= nil and auth_header ~= '' then

    -- now if we don't have a bearer token, then we need to either use the apikey/apisecret or generate one from the user/pass

    -- first try to authenticate with apikey/apisecret
    log( 'trying as api creds' .. auth_url )

    local res, err = hc:request_uri( auth_url, {
      timeout = 3000,
      method = "GET",
      headers = { ["Authorization"] = auth_header
      }
    })
    -- log( 'response code: ' .. code )
    -- log( 'response body: ' .. body )

    if res ~= nil then
      if res.status == ngx.HTTP_OK then
        log( 'successfully authed with api credentials ' .. auth_header )
        return
      end
    else
      log( 'error : ' .. err )
    end

    -- if we reach here we want to try to use the basic auth to generate a token
    log( 'using basic auth to generate a token' )

    -- Test Authentication header is set and with a value
    local h = ngx.req.get_headers()['Authorization']
    if h == nil or auth_header:find(" ") == nil then
      log( 'FAILED to find Authorization header' )
      ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
      ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end

    local divider = h:find(' ')
    if h:sub(0, divider-1) ~= 'Basic' then
      log( 'FAILED to find Authorization header' )
      ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
      ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end

    local auth = ngx.decode_base64(h:sub(divider+1))
    if auth == nil or auth:find(':') == nil then
      log( 'FAILED to find Authorization header' )
      ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
      ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end

    divider = auth:find(':')
    local username = auth:sub(0, divider-1)
    local password = auth:sub(divider+1)

    log( 'generating token with ' .. username .. ':' .. password )

    local res, err = hc:request_uri( token_url, {
      timeout = 3000,
      body = "grant_type=password&username="..ngx.escape_uri(username).."&password="..ngx.escape_uri(password),
      method = "POST",
      headers = { ["Content-Type"] = "application/x-www-form-urlencoded"
      }
    })

    if res ~= nil then
      log( 'token response code : ' .. res.status )

      if res.status == ngx.HTTP_OK then
        -- successfully generated a bearer token
        local cjson = require "cjson"
        local value=cjson.new().decode(res.body)
        bearer_token = value.access_token
        log( 'generated bearer token : ' .. bearer_token )

        -- get the token and set the cookie
        ngx.header['Set-Cookie'] = 'auth-token='..bearer_token..'; path=/'

        -- exit successful
        return
      end
    else
      log( 'token response error : ' .. err )
    end
  end

  log( 'failed all auth attempts' )
  ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
  ngx.exit(ngx.HTTP_UNAUTHORIZED)

end


return CustomHandler
