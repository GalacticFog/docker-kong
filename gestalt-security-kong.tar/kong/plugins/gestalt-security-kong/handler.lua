local BasePlugin = require "kong.plugins.base_plugin"

local CustomHandler = BasePlugin:extend()
local LOG_LEVEL = ngx.NOTICE

function CustomHandler:new()
  CustomHandler.super.new(self, "my-custom-plugin")
end

function log( thing )
  ngx.log( LOG_LEVEL, thing )
end

function authorize( gestaltUser, gestaltGroups, config )
  log( 'authorizing user' )

  -- if there is a user or group list then we have to do the authZ step
  local users = config.users
  local groups = config.groups

  if (users == nil or users == '') and (groups == nil or groups == '') then
    log( 'no authorization constructs defined' )
    return
  end

  -- ------------------
  --
  -- USERS
  --
  -- ------------------

  local cjson = require "cjson"

  if (users ~= nil and users ~= '') then
    log( 'checkout authZ users' )
    local parsedUsers = cjson.new().decode(users)
    for _,v in pairs(parsedUsers) do
      -- log( 'checkout user : ' .. v .. ' ==? ' .. gestaltUser )
      if v == gestaltUser then
        log( 'found user in permitted users' )
        return
      end
    end
  end

  log( 'user NOT authorized' )

  -- ------------------
  --
  -- GROUPS
  --
  -- ------------------

  -- check against the groups
  if (groups ~= nil and groups ~= '') then
    log( 'checkout authZ groups' )

    local parsedGroups = cjson.new().decode(groups)

    -- out loop on my groups for this user
    for _,v in pairs(gestaltGroups) do

      local groupId = v.id

      for _,g in pairs(parsedGroups) do
        -- log('trying to match : ' .. groupId .. ' ==? ' .. g )
        if g == groupId then
          log('FOUND group, authorized...' )
          return
        end
      end
    end
  end
  log( 'group NOT authorized' )

  -- if we reached here, it's cause we failed all the other ways
  ngx.exit(ngx.HTTP_UNAUTHORIZED)
end

function CustomHandler:access(config)
  CustomHandler.super.access(self)
  log( 'starting auth plugin...')

  -- variables read form the environment

  local protocol    = config.auth_protocol
  local host        = config.auth_host
  local port        = config.auth_port
  local base        = protocol .. "://" .. host .. ":" .. port
  local keys_url 	= base .. "/auth"
  local token_url 	= base .. "/oauth/inspect"
  local auth_realm 	= base .. "/oauth/issue"

  local app_key 	= config.app_key
  local app_secret 	= config.app_secret

  local auth_header = ngx.req.get_headers().authorization
  local system_header = "Basic " .. ngx.encode_base64(app_key .. ":" .. app_secret)

  -- ------------------
  --
  -- COOKIES!
  --
  -- ------------------

  local cookie = nil
  if ngx.var.cookie ~= nil then
    cookie = ngx.var.cookie_auth-token
  end

  local bearer_token = ""

  -- Check that the cookie exists.
  if not auth_header or auth_header == '' then
    if cookie ~= nil then
      log( 'FOUND Cookie : ' .. cookie )
      bearer_token = cookie
    end
  end

  -- check that the header is present, and if not send authenticate header
  if bearer_token == '' and (not auth_header or auth_header == '') then
    log( 'FAILED to find Authorization header' )
    ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
    ngx.exit(ngx.HTTP_UNAUTHORIZED)
  end

  log( 'auth header : ' .. auth_header )

  -- ------------------
  --
  -- BEARER TOKEN
  --
  -- ------------------


  local http = require "resty.http"
  local hc = http:new()

  -- if they handed us a Bearer token, simply use it
  if string.find( auth_header, "Bearer" ) then
    log( 'FOUND bearer token : ' .. auth_header )

    local divider = auth_header:find(' ')
    local token = auth_header:sub(divider+1)

    bearer_token = token
  end

  --if we've either found a token or used a cookie, just test it
  if bearer_token ~= nil and bearer_token ~= '' then
    log( 'sending request to ' .. token_url )

    --local ok, code, headers, status, body  = hc:request {
    local res, err = hc:request_uri( token_url, {
      timeout = 3000,
      body = "token=" .. bearer_token,
      method = "POST",
      headers = { ["Content-Type"] = "application/x-www-form-urlencoded",
                  ["Authorization"] = system_header
      }
    })

    if( res ~= nil ) then
      -- log( 'response code: ' .. res.status )
      if res.status == ngx.HTTP_OK then
        -- this call always returns 200 OK so check the body
        local cjson = require "cjson"
        local gestaltAccount = cjson.new().decode(res.body)

        if( gestaltAccount.active == true ) then
          authorize( gestaltAccount.gestalt_account.id, gestaltAccount.gestalt_groups, config )
          return
        else
          log( 'token is not active' )
          ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
          ngx.exit(ngx.HTTP_UNAUTHORIZED)
        end
      end
    end

    -- log( 'error message : ' .. err )
  end

  -- ------------------
  --
  -- API KEY/SECRET
  --
  -- ------------------

  if auth_header ~= nil and auth_header ~= '' then

    -- now if we don't have a bearer token, then we need to use the apikey/apisecret

    -- first try to authenticate with apikey/apisecret
    log( 'trying as api creds' .. keys_url )

    local res, err = hc:request_uri( keys_url, {
      timeout = 3000,
      method = "POST",
      headers = { ["Authorization"] = auth_header
      }
    })
    -- log( 'response code: ' .. code )
    -- log( 'response body: ' .. body )

    -- 200 OK to this endpoint means we've successfully been authenticated
    if res ~= nil then
      if res.status == ngx.HTTP_OK then

        local cjson = require "cjson"
        local gestaltAccount = cjson.new().decode(res.body)

        log( 'successfully authed with api credentials ' .. auth_header )
        authorize( gestaltAccount.account.id, gestaltAccount.groups, config )
        return
      end
    else
      log( 'error : ' .. err )
    end
  end

  log( 'failed all auth attempts' )
  ngx.header['WWW-Authenticate'] = 'Basic realm="' .. auth_realm ..'"'
  ngx.exit(ngx.HTTP_UNAUTHORIZED)

end


return CustomHandler
