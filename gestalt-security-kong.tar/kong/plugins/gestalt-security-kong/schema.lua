return {
    no_consumer = true,
    fields = {
        app_key = {type = "string", required = true},
        app_secret = {type = "string", required = true},
        auth_url = {type = "string", required = true},
        auth_token_url = {type = "string", required = true},
        auth_realm = {type = "string", required = true}
    }
}

