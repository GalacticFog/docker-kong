return {
    no_consumer = true,
    fields = {
        app_key = {type = "string", required = true},
        app_secret = {type = "string", required = true},
        auth_host = {type = "string", required = true},
        auth_port = {type = "string", required = true},
        auth_protocol = {type = "string", required = true},
        users = {type = "string", required = false},
        groups = {type = "string", required = false}
    }
}

